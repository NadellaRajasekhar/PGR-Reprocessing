sap.ui.define([
	"compgr.suspence./project1_pgr/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
